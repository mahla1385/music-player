# Pasino (android application)


<img src="https://github.com/Rayapars/pasino/blob/master/assets/images/logo.png?raw=true=250x250?raw=true" alt="image_demo" width="100" height="100">

One of the projects of Raya Pars company

## Communication with Raya Pars Co

![](https://rayapars.ir/assets/rayapars.png)

:arrow_forward:  **Phone**: 05138665472

:arrow_forward:  **Email**: info@rayapars.ir

:arrow_forward:  **Telegram**: https://t.me/rayapars_ir

:arrow_forward:  **Instagram**: https://instagram.com/rayapars

:arrow_forward:  **Website**: https://rayapars.ir/
