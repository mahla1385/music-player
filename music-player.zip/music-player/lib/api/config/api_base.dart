

enum TypeState{
  init,
  loading,
  next,
  empty,
  networkError,
  error,
}

