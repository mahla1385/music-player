import 'package:flutter/material.dart';
class InitBloc extends StatelessWidget {
  final Widget child;
  const InitBloc({super.key,required this.child});

  @override
  Widget build(BuildContext context) {
    return child;
  }
}
